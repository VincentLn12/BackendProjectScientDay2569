﻿namespace ProjectScientDay2568.Models.Dtos.Team
{
    public class StudentDto
    {
        public int StudentID { get; set; }
        public int TitlePrefix { get; set; } 
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public int TeamID { get; set; }
        public bool IsMainMember { get; set; } = true;


    }
}
